install.packages("tidyverse")
install.packages("skimr")
install.packages("wordcloud2")

install.packages("nhanesA")

library(tidyverse)
library(nhanesA)
