Today's data: 
National Center for Health Statistics. (2017) About the national health and nutrition examination survey. Retrieved from https://www.cdc.gov/nchs/nhanes/about_nhanes.htm#content. 


As prepared by:
Endres, C.J.(2022, August). nhanesA: R package for browsing and retrieving NHANES data. Retrieved from https://github.com/cjendres1/nhanes. 

Open Comparison.rmd to get started.