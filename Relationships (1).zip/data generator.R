colA <- 
  sample(1:100,50)
colB <- 
  colA+5
colC <- 
  colA+sample(-3:3,1)
colD <- 
  sample(100:200,50)

csv_prep <- 
  data.frame(colA, colB, colC, colD)

csv_prep %>% 
  write.csv("mydata.csv", row.names = F)
